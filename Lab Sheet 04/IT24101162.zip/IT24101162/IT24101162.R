setwd("C:\\Users\\IT24101162\\Desktop\\IT24101162")
branch_data<- read.table("Exercise.txt",header=TRUE,sep=",")
head(branch_data)

boxplot(branch_data$Sales_X1,
        main="Boxplot of Sales(x1)",
        ylab="Sales",
        col="lightblue"
        )

summary_adv <- summary(branch_data$Advertising_X2)
print(summary_adv)


min_adv <- min(branch_data$Advertising_X2)
Q1_adv <- quantile(branch_data$Advertising_X2, 0.25)
median_adv <- median(branch_data$Advertising_X2)
Q3_adv <- quantile(branch_data$Advertising_X2, 0.75)
max_adv <- max(branch_data$Advertising_X2)


IQR_adv <- IQR(branch_data$Advertising_X2)


cat("Five-Number Summary for Advertising:\n")
cat("Minimum:", min_adv, "\n")
cat("First Quartile (Q1):", Q1_adv, "\n")
cat("Median:", median_adv, "\n")
cat("Third Quartile (Q3):", Q3_adv, "\n")
cat("Maximum:", max_adv, "\n")
cat("Interquartile Range (IQR):", IQR_adv, "\n")


find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR
  upper_bound <- Q3 + 1.5 * IQR
  
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}


outliers_years <- find_outliers(branch_data$Years_X3)
print(outliers_years)